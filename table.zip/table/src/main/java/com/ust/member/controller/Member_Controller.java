package com.ust.member.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.member.model.Member;
import com.ust.member.service.MemberService;

@RestController
public class Member_Controller {
	
	@Autowired
	MemberService memService;
	
	
	@RequestMapping("hi")
	@GetMapping

	public String hello()
	{
		return "hello world";
	}
		
	//-----------------------------------------
	
	@RequestMapping("display")
	@GetMapping
	public List<Member> display()
	{
	    	
	return memService.displayMember();
	}
	
	
	// Add User
		@RequestMapping("add")
		@PostMapping
		public Member addUsers(@RequestBody Member member) {

			return memService.addMember(member);

			
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	