package com.ust.member.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;


@Entity
public class Member {

	@Id
	// @NotNull
	// @GeneratedValue(strategy=GenerationType.IDENTITY)
	int mbr_id;
	String f_name;
	String l_name;
	String dob;
	String gnr_cd;
	String mc_id;

	@OneToMany(fetch = FetchType.EAGER,cascade=CascadeType.ALL)
//	@JoinColumn(name = "mem_cntrct_id")
	List<Member_Contract> member_Contracts;

	public Member(int mbr_id, String f_name, String l_name, String dob, String gnr_cd, String mc_id,
			List<Member_Contract> member_Contracts) {
		super();
		this.mbr_id = mbr_id;
		this.f_name = f_name;
		this.l_name = l_name;
		this.dob = dob;
		this.gnr_cd = gnr_cd;
		this.mc_id = mc_id;
		this.member_Contracts = member_Contracts;
	}

	public int getMbr_id() {
		return mbr_id;
	}

	public void setMbr_id(int mbr_id) {
		this.mbr_id = mbr_id;
	}

	public String getF_name() {
		return f_name;
	}

	public void setF_name(String f_name) {
		this.f_name = f_name;
	}

	public String getL_name() {
		return l_name;
	}

	public void setL_name(String l_name) {
		this.l_name = l_name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGnr_cd() {
		return gnr_cd;
	}

	public void setGnr_cd(String gnr_cd) {
		this.gnr_cd = gnr_cd;
	}

	public String getMc_id() {
		return mc_id;
	}

	public void setMc_id(String mc_id) {
		this.mc_id = mc_id;
	}

	public List<Member_Contract> getMember_Contracts() {
		return member_Contracts;
	}

	public void setMember_Contracts(List<Member_Contract> member_Contracts) {
		this.member_Contracts = member_Contracts;
	}

	public Member() {
		super();
	}

}
