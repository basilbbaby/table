package com.ust.member.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.ForeignKey;

@Entity
public class Member_Contract {

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	int mem_cntrct_id;
	int scr_cd;
	int hc_id;
	String grp_id;
	/*@ManyToOne
	Member member;*/
	
	
	public int getMem_cntrct_id() {
		return mem_cntrct_id;
	}
	public void setMem_cntrct_id(int mem_cntrct_id) {
		this.mem_cntrct_id = mem_cntrct_id;
	}
	public int getScr_cd() {
		return scr_cd;
	}
	public void setScr_cd(int scr_cd) {
		this.scr_cd = scr_cd;
	}
	public int getHc_id() {
		return hc_id;
	}
	public void setHc_id(int hc_id) {
		this.hc_id = hc_id;
	}
	public String getGrp_id() {
		return grp_id;
	}
	public void setGrp_id(String grp_id) {
		this.grp_id = grp_id;
	}
	public Member_Contract(int mem_cntrct_id, int scr_cd, int hc_id, String grp_id) {
		super();
		this.mem_cntrct_id = mem_cntrct_id;
		this.scr_cd = scr_cd;
		this.hc_id = hc_id;
		this.grp_id = grp_id;
	}
	public Member_Contract() {
		super();
	}
	
	
	
	
	
}

