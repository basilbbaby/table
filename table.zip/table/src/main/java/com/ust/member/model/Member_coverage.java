package com.ust.member.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Member_coverage {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int cvr_id;
	int sub_grp_id;
	String cvrg_eftv_dt;
	String cvrg_tr_dt;

}
